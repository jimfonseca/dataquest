## 2. Partititioning the data ##

import pandas as pd

admissions = pd.read_csv("admissions.csv")
admissions["actual_label"] = admissions["admit"]
admissions = admissions.drop("admit", axis=1)

shuffled_index = np.random.permutation(admissions.index)
shuffled_admissions = admissions.loc[shuffled_index]
admissions = shuffled_admissions.reset_index()

admissions.ix[0:128, "fold"]=1
admissions.ix[129:257, "fold"]=2
admissions.ix[258:386, "fold"]=3
admissions.ix[387:514, "fold"]=4
admissions.ix[515:644, "fold"]=5

admissions["fold"]  = admissions["fold"].astype('int')

print(admissions.head())
print(admissions.tail())

## 3. First iteration ##

from sklearn.linear_model import LogisticRegression

logreg = LogisticRegression()
training = admissions[admissions["fold"] != 1]
test = admissions[admissions["fold"] == 1]
#trainingy = admissions[admissions["fold"] == 1]


logreg.fit(training[["gpa"]], training["actual_label"])
test["labels"] = logreg.predict(test[["gpa"]])

iteration_one_accuracy = len(test[test["labels"]==test["actual_label"]])*1.0/len(test)




## 4. Function for training models ##

# Use np.mean to calculate the mean.
import numpy as np
from sklearn.linear_model import LogisticRegression


def train_and_test(df,fold_list):
    acc_list = []
    for f in fold_list:
        logreg = LogisticRegression()
        training = admissions[admissions["fold"] != f]
        test = admissions[admissions["fold"] == f]
    #trainingy = admissions[admissions["fold"] == 1]


        logreg.fit(training[["gpa"]], training["actual_label"])
        test["labels"] = logreg.predict(test[["gpa"]])

        acc_list.append(len(test[test["labels"]==test["actual_label"]])*1.0/len(test))
    return acc_list 
fold_ids = [1,2,3,4,5]


accuracies = train_and_test(admissions, fold_ids)
average_accuracy = sum(accuracies) * 1.0 / len(fold_ids)

print (accuracies)
print (average_accuracy)

## 5. Sklearn ##

from sklearn.cross_validation import KFold
from sklearn.cross_validation import cross_val_score

admissions = pd.read_csv("admissions.csv")
admissions["actual_label"] = admissions["admit"]
admissions = admissions.drop("admit", axis=1)
kf = KFold(n=len(admissions), n_folds=5,shuffle=True, random_state = 8)
lr = LogisticRegression()
#cross_val_score(estimator, X, Y, scoring=None, cv=None)
accuracies = cross_val_score(lr, admissions[["gpa"]],admissions[["actual_label"]], scoring="accuracy", cv=kf)
average_accuracy = sum(accuracies) / 5