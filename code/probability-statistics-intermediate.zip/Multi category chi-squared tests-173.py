## 2. Calculating expected values ##

rows = 32561
males_over50k = 0.669*0.241*rows
males_under50k = 0.669*0.759*rows
females_over50k = 0.331*0.241*rows
females_under50k = 0.331*0.759*rows

## 3. Calculating chi-squared ##

def x(o,e):
    return (o-e)**2/e
chisq_gender_income = x(6662,5249.8) + x(1179,2597.4) + x(15128,16533.5) + x(9592,8180.3)

## 4. Finding statistical significance ##

import numpy as np
from scipy.stats import chisquare

#chisq_gender_income = x(6662,5249.8) + x(1179,2597.4) + x(15128,16533.5) + x(9592,8180.3)
observed = np.array([6662, 1179, 15128, 9592])
expected = np.array([5249.8,2597.4,16533.5,81080.3])
chisquare_value, pvalue_gender_income = chisquare(observed, expected)

## 5. Cross tables ##

table = pandas.crosstab(income["sex"],[income["race"]])
print(table)

## 6. Finding expected values ##

import pandas
from scipy.stats import chi2_contingency
chisq_value, pvalue_gender_race,df,expected = chi2_contingency(table)