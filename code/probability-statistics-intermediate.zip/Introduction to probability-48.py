## 1. Probability basics ##

# Print the first two rows of the data.
print(flags[:2])
most_bars_country = flags["name"][flags["bars"].idxmax()]

highest_population_country = flags["name"][flags["population"].idxmax()]

## 2. Calculating probability ##

total_countries = flags.shape[0]
orange_probability = flags[flags["orange"] == 1].shape[0] / total_countries

stripe_probability = flags[flags["stripes"] > 1].shape[0] / total_countries

## 3. Conjunctive probabilities ##

five_heads = .5 ** 5
ten_heads = 0.5 ** 10
hundred_heads = 0.5 ** 100

## 4. Dependent probabilities ##

# Remember that whether a flag has red in it or not is in the `red` column.
total_countries = flags.shape[0]
three_red  = flags[flags["red"] == 1].shape[0] / total_countries * (flags[flags["red"] == 1].shape[0] -1 ) / (total_countries - 1) * (flags[flags["red"] == 1].shape[0] -2 ) / (total_countries - 2)


## 5. Disjunctive probability ##

start = 1
end = 18000
hundred_count = 0
seventy_count = 0
for i in range(1,18000+1):
    if i % 100 == 0:
        hundred_count += 1
    if i % 70 == 0:
        seventy_count += 1
        
hundred_prob = hundred_count /18000
seventy_prob = seventy_count /18000

## 6. Disjunctive dependent probabilities ##

stripes_or_bars = None
red_or_orange = None
ro = flags["red"]
#ro2 = [i for i in flags[2:]]
flags["red_or_orange"] = flags["red"] + flags["orange"]


red_or_orange = flags["red_or_orange"].astype(bool).sum() / len(flags)

flags["stripes_or_bars"] = flags["stripes"] + flags["bars"]
stripes_or_bars = flags["stripes_or_bars"].astype(bool).sum() / len(flags)
    
    



## 7. Disjunctive probabilities with multiple conditions ##

heads_or = 1 - .5*.5*.5
