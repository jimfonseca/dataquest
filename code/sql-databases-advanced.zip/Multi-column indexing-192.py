## 1. Introduction ##

import sqlite3
conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query_one = '''EXPLAIN QUERY PLAN SELECT * FROM facts WHERE population > 1000000 AND population_growth < 0.05;'''
query_plan_one = cur.execute(query_one).fetchall()
print(query_plan_one)

## 2. Query plan for multi-column queries ##

conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query_idx = '''CREATE INDEX if not exists pop_idx on facts(population);'''
query_idx2 = '''CREATE INDEX if not exists pop_growth_idx on facts(population_growth);'''
cur.execute(query_idx)
cur.execute(query_idx2)
query_plan = '''EXPLAIN QUERY PLAN SELECT * FROM facts WHERE population > 1000000 AND population_growth < 0.05;'''
query_plan_two = cur.execute(query_plan).fetchall()
print(query_plan_two)

## 5. Creating a multi-column index ##

conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query = '''CREATE INDEX IF NOT EXISTS pop_pop_growth_idx ON facts(population, population_growth);'''
cur.execute(query)
query_three = '''EXPLAIN QUERY PLAN  SELECT * FROM facts WHERE population > 1000000 AND population_growth < 0.05;'''
query_plan_three = cur.execute(query_three).fetchall()
print(query_plan_three)

## 6. Covering index ##

conn = sqlite3.connect("factbook.db")
conn.execute("create index if not exists pop_pop_growth_idx on facts(population, population_growth);")
query_plan_four = conn.execute("EXPLAIN QUERY PLAN SELECT population, population_growth FROM facts WHERE population > 1000000 AND population_growth < 0.05;").fetchall()
print(query_plan_four)

## 7. Covering index for single column ##

conn = sqlite3.connect("factbook.db")
conn.execute("create index if not exists pop_pop_growth_idx on facts(population, population_growth);")
query_plan_five = conn.execute("EXPLAIN QUERY PLAN SELECT population FROM facts WHERE population > 1000000;").fetchall()
print(query_plan_five)