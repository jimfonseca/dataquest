## 1. Introduction ##

import sqlite3
conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query = '''PRAGMA TABLE_INFO(facts);'''
schema = cur.execute(query).fetchall()
for l in schema:
    print(l)

## 3. Explain query plan ##

conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query1 = '''EXPLAIN QUERY PLAN SELECT * FROM facts WHERE area > 40000;'''
query_plan_one = cur.execute(query1).fetchall()
query2 = '''EXPLAIN QUERY PLAN SELECT area FROM facts WHERE area > 40000;'''
query_plan_two = cur.execute(query2).fetchall()
query3 = '''EXPLAIN QUERY PLAN SELECT * FROM facts WHERE name == 'Czech Republic';'''
query_plan_three = cur.execute(query3).fetchall()
print(query_plan_one)
print(query_plan_two)
print(query_plan_three)

## 5. Time complexity ##

conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query_four = '''EXPLAIN QUERY PLAN select * from facts where id == 20;'''
query_plan_four = cur.execute(query_four).fetchall()
print(query_plan_four)

## 9. All together now ##

conn = sqlite3.connect("factbook.db")
cur = conn.cursor()
query_six = '''EXPLAIN QUERY PLAN select * from facts where population > 100000;'''
query_plan_six = cur.execute(query_six).fetchall()
query_idx = '''CREATE INDEX pop_idx ON facts(population);'''
#cur.execute(query_idx)
query_seven = '''EXPLAIN QUERY PLAN select * from facts where population > 100000;'''
query_plan_seven = cur.execute(query_seven).fetchall()
print(query_plan_six)
print(query_plan_seven)