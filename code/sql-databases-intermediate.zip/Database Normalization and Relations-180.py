## 4. Querying a normalized database ##

query = '''SELECT ceremonies.year, nominations.movie FROM nominations INNER JOIN ceremonies on nominations.ceremony_id == ceremonies.id WHERE nominations.nominee == "Natalie Portman";'''

portman_movies = conn.execute(query).fetchall()

for p in portman_movies:
    print(p)



## 6. Join table ##

q1 = '''select * from movies_actors LIMIT 5;'''
five_join_table = conn.execute(q1).fetchall()

q2 = '''select * from actors LIMIT 5;'''
five_actors = conn.execute(q2).fetchall()

q3 = '''select * from movies LIMIT 5;'''
five_movies = conn.execute(q3).fetchall()


print(five_join_table)
print(five_actors)
print(five_movies)

## 7. Querying a many-to-many relation ##

query = '''SELECT actors.actor,movies.movie FROM movies INNER JOIN movies_actors ON movies.id == movies_actors.movie_id INNER JOIN actors ON movies_actors.actor_id == actors.id WHERE movies.movie == "The King's Speech";'''
kings_actors = conn.execute(query).fetchall()
print(kings_actors)

## 8. Practice: querying a many-to-many relation ##

query = '''SELECT movies.movie,actors.actor FROM movies INNER JOIN movies_actors ON movies.id == movies_actors.movie_id INNER JOIN actors ON actors.id == movies_actors.actor_id WHERE actors.actor = "Natalie Portman";'''
portman_joins = conn.execute(query).fetchall()
print(portman_joins)