## 3. Psycopg2 ##

import psycopg2
conn = psycopg2.connect("dbname=dq user=dq")
cur = conn.cursor()
print(cur)

## 4. Creating a table ##

conn = psycopg2.connect("dbname=dq user=dq")
query = '''CREATE TABLE notes(id int PRIMARY KEY, body text, title text);'''
cur = conn.cursor()
cur.execute(query)
conn.close()

## 5. SQL Transactions ##

conn = psycopg2.connect("dbname=dq user=dq")
query = '''CREATE TABLE notes(id int PRIMARY KEY, body text, title text);'''
cur = conn.cursor()
cur.execute(query)
conn.commit()
conn.close()


## 6. Autocommitting ##

conn = psycopg2.connect("dbname=dq user=dq")
conn.autocommit = True
query = '''CREATE TABLE facts(id int PRIMARY KEY, country text, value integer);'''
cur = conn.cursor()
cur.execute(query)
conn.close()

## 7. Executing queries ##

conn = psycopg2.connect("dbname=dq user=dq")
conn.autocommit = True
query = '''INSERT INTO notes VALUES (1, 'Do more missions on Dataquest.', 'Dataquest reminder');'''
query2 = '''SELECT * from notes;'''
cur = conn.cursor()
cur.execute(query2)
rows = cur.fetchall()
print(rows)
#print(cur.execute(query2).fetchall())
conn.close()



## 8. Creating a database ##

conn = psycopg2.connect("dbname=dq user=dq")
conn.autocommit = True
cur = conn.cursor()
query = '''CREATE DATABASE income OWNER dq;'''
cur.execute(query)
conn.close()


## 9. Deleting a database ##

conn = psycopg2.connect("dbname=dq user=dq")
conn.autocommit = True
cur = conn.cursor()
query = '''DROP DATABASE income;'''
cur.execute(query)
conn.close()