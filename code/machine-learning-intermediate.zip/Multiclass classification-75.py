## 1. Introduction to the data ##

import pandas as pd
cars = pd.read_csv("auto.csv")

unique_regions = cars["origin"].unique()
print(unique_regions)

## 2. Dummy variables ##

dummy_cylinders = pd.get_dummies(cars["cylinders"], prefix="cyl")
cars = pd.concat([cars, dummy_cylinders], axis=1)
print(cars.head())
dummy_years = pd.get_dummies(cars["year"],prefix="year")
cars = pd.concat([cars,dummy_years],axis=1)
cars = cars.drop(["cylinders","year"],axis=1)
print(cars.head())

## 3. Multiclass classification ##

shuffled_rows = np.random.permutation(cars.index)
shuffled_cars = cars.iloc[shuffled_rows]
train = shuffled_cars.iloc[:274]
test = shuffled_cars.iloc[274:]
print(len(shuffled_cars)*0.7)
print(int(cars.shape[0] * .70))

## 4. Training a multiclass logistic regression model ##

from sklearn.linear_model import LogisticRegression

unique_origins = cars["origin"].unique()
unique_origins.sort()

models = {}


logr = LogisticRegression()
fit_cars = cars.drop(["mpg","displacement","horsepower", "weight","acceleration","origin"],axis=1)

for i in range(1,4):
    models[i] = logr.fit(fit_cars, (cars["origin"]==i))
#models[2] = logr.fit(fit_cars, (cars["origin"]==2))
#models[3] = logr.fit(fit_cars, (cars["origin"]==3))
                     #print(fit_cars.head())
    
    
    

## 5. Testing the models ##

testing_probs = pd.DataFrame(columns=unique_origins)
for i in range(1,4):

    testing_probs[i] = models[i].predict_proba(test[features])[:,1]
print(testing_probs.head())
x = testing_probs[1]+testing_probs[2]+testing_probs[3]

## 6. Choose the origin ##

predicted_origins = testing_probs.idxmax(axis=1)
print(predicted_origins)