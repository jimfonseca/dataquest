## 2. Reading in the data ##

/home/dq/scripts$ python predict.py

## 3. Generating indicators ##

/home/dq/scripts$ python predict.py

## 4. Splitting up the data ##

/home/dq/scripts$ python predict.py

## 5. Making predictions ##

/home/dq/scripts$ python predict.py