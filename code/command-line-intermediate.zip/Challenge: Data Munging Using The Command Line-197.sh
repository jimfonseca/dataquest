## 1. Data munging ##

/home/dq$ ls -l

## 2. Data exploration ##

/home/dq$ head -n 10 *.csv

## 3. Filtering ##

/home/dq$ tail -n 42729 >> combined_hud.csv

## 4. Consolidating datasets ##

/home/dq$ tail -n 10 Hud_2013.csv

## 5. Counting ##

/home/dq$ grep "1980-1989" combined_hud.csv | wc -l