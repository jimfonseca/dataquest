## 1. Jupyter console ##

/home/dq$ ipython

## 2. Getting help ##

/home/dq$ ipython

## 3. Persistent sessions ##

/home/dq$ ipython

## 4. Jupyter magics ##

/home/dq$ ipython

## 5. Autocompletion ##

/home/dq$ ipython

## 6. Accessing the shell ##

/home/dq$ ipython

## 7. Pasting in code ##

/home/dq$ ipython

## 8. Next steps ##

/home/dq$ ipython