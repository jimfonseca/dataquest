## 3. Converting categorical variables ##

# Convert a single column from text categories into numbers.
col = pandas.Categorical.from_array(income["workclass"])
income["workclass"] = col.codes
print(income["workclass"].head(5))

tochange = ["education", "marital_status", "occupation", "relationship", "race", "sex", "native_country", "high_income"]
for t in tochange:
    income[t] = pandas.Categorical.from_array(income[t]).codes

## 5. Performing a split ##

private_incomes = income[income["workclass"] == 4]
public_incomes = income[income["workclass"] != 4]
# Enter your code here.

## 8. Entropy ##

import math
# We'll do the same calculation we did above, but in Python.
# Passing 2 as the second parameter to math.log will take a base 2 log.
entropy = -(2/5 * math.log(2/5, 2) + 3/5 * math.log(3/5, 2))
print(entropy)

num_ones = len(income[income["high_income"] == 1])
ml = len(income)

mp = num_ones * 1.0 /ml #this is the 2/5 part
mq = (ml-num_ones)/ml #this is the 3/5 part

income_entropy = -(mp * math.log(mp, 2) + mq * math.log(mq, 2))

## 9. Information gain ##

import numpy

def calc_entropy(column):
    """
    Calculate entropy given a pandas Series, list, or numpy array.
    """
    # Compute the counts of each unique value in the column.
    counts = numpy.bincount(column)
    # Divide by the total column length to get a probability.
    probabilities = counts / len(column)
    
    # Initialize the entropy to 0.
    entropy = 0
    # Loop through the probabilities, and add each one to the total entropy.
    for prob in probabilities:
        if prob > 0:
            entropy += prob * math.log(prob, 2)
    
    return -entropy

# Verify our function matches our answer from earlier.
entropy = calc_entropy([1,1,0,0,1])
print(entropy)

information_gain = entropy - ((.8 * calc_entropy([1,1,0,0])) + (.2 * calc_entropy([1])))
print(information_gain)

med_age = income["age"].median()
left_split = income[income["age"] <= med_age]
right_split = income[income["age"] > med_age]
#target variable is high_income
#split variable A is age

# for all the values in A which are 0 and 1
#we want 
income_entropy = calc_entropy(income["high_income"])
#age_entropy = calc_entropy(income["high_income"])
#A_zeros = len(income[income["high_income"] == 0])*1.0/len(income)
#A_ones = len(income[income["high_income"] == 1])*1.0/len(income)

A_zeros = left_split.shape[0] / income.shape[0] #left
A_ones = right_split.shape[0] / income.shape[0] #right

age_information_gain = income_entropy - (A_zeros * calc_entropy(left_split["high_income"])) - (A_ones * calc_entropy(right_split["high_income"]))

#income[income[right_split]]["split_age"] = 1
#income[income[left_split]]["split_age"] = 0








## 10. Finding the best split ##

def calc_information_gain(data, split_name, target_name):
    """
    Calculate information gain given a dataset, column to split on, and target.
    """
    # Calculate original entropy.
    original_entropy = calc_entropy(data[target_name])
    
    # Find the median of the column we're splitting.
    column = data[split_name]
    median = column.median()
    
    # Make two subsets of the data based on the median.
    left_split = data[column <= median]
    right_split = data[column > median]
    
    # Loop through the splits, and calculate the subset entropy.
    to_subtract = 0
    for subset in [left_split, right_split]:
        prob = (subset.shape[0] / data.shape[0]) 
        to_subtract += prob * calc_entropy(subset[target_name])
    
    # Return information gain.
    return original_entropy - to_subtract

# Verify that our answer is the same as in the last screen.
print(calc_information_gain(income, "age", "high_income"))

columns = ["age", "workclass", "education_num", "marital_status", "occupation", "relationship", "race", "sex", "hours_per_week", "native_country"]

information_gains = []
highest_gain = -1
for c in columns:
    information_gains.append(calc_information_gain(income,c,"high_income"))
    
index = information_gains.index(max(information_gains))
highest_gain = columns[index]
    