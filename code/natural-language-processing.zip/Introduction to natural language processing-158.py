## 3. Tokenization ##

tokenized_headlines = []
for s in submissions["headline"]:
    tokenized_headlines.append(s.split(" "))

## 4. Preprocessing ##

punctuation = [",", ":", ";", ".", "'", '"', "’", "?", "/", "-", "+", "&", "(", ")"]
clean_tokenized = []
for i in tokenized_headlines:
    this_token = []
    for j in i:
        cleaner = j.lower()
        for p in punctuation:
            cleaner = cleaner.replace(p,"")
        this_token.append(cleaner)    
    clean_tokenized.append(this_token)
        

## 5. Assembling a matrix ##

import numpy as np
unique_tokens = []
single_tokens = []
for i in clean_tokenized:
    for j in i:
        if j in single_tokens:
            unique_tokens.append(j)
        else:
            single_tokens.append(j)



counts = pd.DataFrame(0,index=np.arange(len(clean_tokenized)),columns=unique_tokens)

## 6. Counting tokens ##

# clean_tokenized and counts have been loaded in.
for i,val in enumerate(clean_tokenized):
    for j in val:
        if j in unique_tokens:
            counts.iloc[i][j] += 1

## 7. Removing extraneous columns ##

word_counts = counts.sum(axis = 0)

counts = counts.loc[:,(word_counts >= 5) & (word_counts <=100)]

    #print(str(w)+"--"+str(v))
    
    #    if w < 5 or w > 100:
#        counts.loc[w].drop(inplace = True)

# clean_tokenized and counts have been loaded in.

## 9. Making predictions ##

from sklearn.linear_model import LinearRegression

clf = LinearRegression()

clf.fit(X_train, y_train)
predictions = clf.predict(X_test)

## 10. Calculating error ##

mysum = 0
for i in range(len(y_test)):
    mysum += (y_test - predictions[i])**2
mse = mysum / len(y_test)