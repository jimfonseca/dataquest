## 10. Filter ##

def filter_year(line):
    return line[0] != 'YEAR'
    # Write your logic here
#    return True

filtered_daily_show = daily_show.filter(lambda line: filter_year(line))