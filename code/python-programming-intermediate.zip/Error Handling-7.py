## 2. Sets ##

gender = []
for l in legislators:
    gender.append(l[3])
gender = set(gender)
print (gender)

## 3. Exploring the Dataset ##

party = []
for l in legislators:
    party.append(l[6])
party = set(party)
print (party)
print (legislators)

## 4. Missing Values ##

for row in legislators:
    if row[3]=="":
        row[3]="M"

## 5. Parsing Birth Years ##

birth_years = []
for l in legislators:
    parts = l[2].split("-")
    birth_years.append(parts[0])
    

## 6. Try/except Blocks ##

try:
    float("hello")
except Exception:
    print ("Error converting to float.")

## 7. Exception Instances ##

try:
    int('')
except Exception as e:
    print(type(e))
    print(str(e))
    

## 8. The Pass Keyword ##

converted_years = []
for b in birth_years:
    try:
        b = int(b)
    except Exception:
        pass
    converted_years.append(b)
    

## 9. Convert Birth Years to Integers ##

for l in legislators:
    birth_year=l[2].split("-")[0]
    try:
        birth_year = int(birth_year)
    except Exception:
        birth_year = 0
    l.append(birth_year)
    
        

## 10. Fill in Years Without a Value ##

last_value = 1
for l in legislators:
    if l[7]==0:
        l[7]=last_value
    last_value = l[7]