## 1. A look at the data ##

import pandas
with open("nba_2013.csv", 'r') as csvfile:
    nba = pandas.read_csv(csvfile)

# The names of the columns in the data.
print(nba.columns.values)

## 3. Euclidean distance ##

selected_player = nba[nba["player"] == "LeBron James"].iloc[0]
distance_columns = ['age', 'g', 'gs', 'mp', 'fg', 'fga', 'fg.', 'x3p', 'x3pa', 'x3p.', 'x2p', 'x2pa', 'x2p.', 'efg.', 'ft', 'fta', 'ft.', 'orb', 'drb', 'trb', 'ast', 'stl', 'blk', 'tov', 'pf', 'pts']
def dist(row):
    sum = 0
    for col in distance_columns:
        
        sum += (selected_player[col]-row[col])**2
    return sum**0.5
        
        

lebron_distance = nba.apply(dist,axis=1)
print (lebron_distance.min())

## 4. Normalizing columns ##

nba_numeric = nba[distance_columns]
#for c in distance_columns:
nba_normalized = (nba_numeric-nba_numeric.mean())/nba_numeric.std()

## 5. Finding the nearest neighbor ##

from scipy.spatial import distance

# Fill in NA values in nba_normalized
nba_normalized.fillna(0, inplace=True)

# Find the normalized vector for lebron james.
lebron_normalized = nba_normalized[nba["player"] == "LeBron James"]

# Find the distance between lebron james and everyone else.
euclidean_distances = nba_normalized.apply(lambda row: distance.euclidean(row, lebron_normalized), axis=1)

distance_frame = pandas.DataFrame(data={"dist": euclidean_distances, "idx": euclidean_distances.index})
distance_frame.sort_values("dist", inplace=True)
second_smallest = distance_frame.iloc[1]["idx"]
most_similar_to_lebron = nba.loc[int(second_smallest)]["player"]

## 8. Computing error ##

actual = test[y_column]
mse = ((predictions - actual)**2).sum()/len(predictions)