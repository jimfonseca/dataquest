## 1. Airline accidents ##

/home/dq/scripts$ python read.py