## 1. Introduction ##

import sqlite3
conn = sqlite3.connect("factbook.db")
pop_avg,pop_growth_avg,birth_rate_avg,death_rate_avg = conn.execute("select avg(population), avg(population_growth), avg(birth_rate), avg(death_rate) from facts;").fetchall()[0]


## 2. Ranges ##

conn = sqlite3.connect("factbook.db")

averages = "select avg(population), avg(population_growth), avg(birth_rate), avg(death_rate), avg(migration_rate) from facts;"
avg_results = conn.execute(averages).fetchall()
pop_avg = avg_results[0][0]
pop_growth_avg = avg_results[0][1]
birth_rate_avg = avg_results[0][2]
death_rate_avg = avg_results[0][3]
mig_rate_avg = avg_results[0][4]
mins = "select min(population), max(population), min(population_growth),max(population_growth), min(birth_rate), max(birth_rate), min(death_rate), max(death_rate) from facts;"
min_results = conn.execute(mins).fetchall()
pop_min = min_results[0][0]
pop_max = min_results[0][1]
pop_growth_min = min_results[0][2]
pop_growth_max = min_results[0][3]
birth_rate_min = min_results[0][4]
birth_rate_max = min_results[0][5]
death_rate_min = min_results[0][6]
death_rate_max = min_results[0][7]


## 3. Filtering ##

conn = sqlite3.connect("factbook.db")
mins = "select min(population), max(population), min(population_growth),max(population_growth), min(birth_rate), max(birth_rate), min(death_rate), max(death_rate) from facts where population < 2000000000 and population > 0;"
min_results = conn.execute(mins).fetchall()
pop_min = min_results[0][0]
pop_max = min_results[0][1]
pop_growth_min = min_results[0][2]
pop_growth_max = min_results[0][3]
birth_rate_min = min_results[0][4]
birth_rate_max = min_results[0][5]
death_rate_min = min_results[0][6]
death_rate_max = min_results[0][7]

## 4. Predicting future population growth ##

import sqlite3
conn = sqlite3.connect("factbook.db")
myquery = ("SELECT round(population + (population * (population_growth / 100)),0) from facts WHERE population > 0 AND population < 7000000000 and population is not null and population_growth is not null;")
projected_population = conn.execute(myquery).fetchall()
print(projected_population[0:10])

## 5. Exploring projected population ##

import sqlite3
conn = sqlite3.connect("factbook.db")
myquery = "select round(min(population + population * population_growth / 100),0), round(max(population + population * population_growth / 100),0), round(avg(population + population * population_growth / 100),0) from facts where population < 7000000000 and population > 0 and population is not null and population_growth is not null;"
pop_proj_min,pop_proj_max,pop_proj_avg = conn.execute(myquery).fetchall()[0]